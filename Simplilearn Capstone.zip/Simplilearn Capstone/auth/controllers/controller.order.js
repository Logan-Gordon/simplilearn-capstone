var OrderModel = require("../models/model.order.js");

var storeOrderInfo = (req, res) => {
    let Order = new OrderModel({
        order: req.body
    });

    Order.save({}, (err, result) => {
        if (err) {
            res.json({ "msg": "Record store Failed" });
        } else {
            // res.send("Record stored succesfully in Db ");
            res.json({ "msg": "Record stored succesfully" });
        }
    });

}
module.exports = { storeOrderInfo }