var BrandModel = require("../models/model.brand.js");

var GetBrandFromDb = (req, res) => {
    BrandModel.find({}, (err, data) => {
        if (err) {
            res.json({ "msg": "No Records Found" });
        } else {
            res.json(data);
        }
    })
}

var GetBrandById = (req, res) => {
    var idInfo = req.params.id;
    BrandModel.find({ _id: idInfo }, (err, data) => {
        if (err) {
            res.json({ "msg": "No Record Found" });
        } else {
            res.json(data);
        }
    })
}

var storeBrandInfo = (req, res) => {
    let Brand = new BrandModel({
        bname: req.body.bname
    });

    Brand.save({}, (err, result) => {
        if (err) {
            res.json({ "msg": "Record store Failed" });
        } else {
            // res.send("Record stored succesfully in Db ");
            res.json({ "msg": "Record stored succesfully" });
        }
    });

}

var UpdateBrandInfo = (req, res) => {
    var updateId = req.body._id;
    var updateBname = req.body.bname;

    BrandModel.update({ _id: updateId }, { $set: { bname: updateBname } }, (err, result) => {
        if (err) throw err;
        if (result.nModified == 0) {
            res.json({ "msg": "Record Update Failed" });
        } else {
            // console.log(result);
            // res.send("Record updated ...  ");
            res.json({ "msg": "Record updated succesfully" });
        }
    })

}

var DeleteBrandInfo = (req, res) => {
    var deleteName = req.params.bname;
    BrandModel.deleteOne({ bname: deleteName }, (err, result) => {
        if (err) throw err;
        // console.log(result);
        // res.send("Record Deleted " + result);
        if (result.deletedCount > 0) {
            res.json({ "msg": "Record deleted succesfully" });
        } else {
            res.json({ "msg": "Record not Present" });
        }
    })
}

module.exports = { GetBrandFromDb, GetBrandById, storeBrandInfo, UpdateBrandInfo, DeleteBrandInfo }