var ProductModel = require("../models/model.product.js");

var GetProductFromDb = (req, res) => {
    ProductModel.find({}, (err, data) => {
        if (err) {
            res.json({ "msg": "No Records Found" });
        } else {
            res.json(data);
        }
    })
}

var GetProductById = (req, res) => {
    var idInfo = req.params.id;
    ProductModel.find({ _id: idInfo }, (err, data) => {
        if (err) {
            res.json({ "msg": "No Record Found" });
        } else {
            res.json(data);
        }
    })
}

var storeProductInfo = (req, res) => {
    let product = new ProductModel({
        _id: req.body._id,
        name: req.body.name,
        details: req.body.details,
        image: req.body.image,
        price: req.body.price,
        brand: req.body.brand
    });

    product.save({}, (err, result) => {
        if (err) {
            res.json({ "msg": "Record store Failed" });
        } else {
            // res.send("Record stored succesfully in Db ");
            res.json({ "msg": "Record stored succesfully" });
        }
    });

}

var UpdateProductInfo = (req, res) => {
    var updateId = req.body._id;
    var updateName = req.body.name;
    var updateDetails = req.body.details;
    var updateImage = req.body.image;
    var updatePrice = req.body.price;
    var updateBrand = req.body.brand;

    ProductModel.updateOne({ _id: updateId }, {
        $set: {
            name: updateName,
            details: updateDetails,
            image: updateImage,
            price: updatePrice,
            brand: updateBrand
        }
    }, (err, result) => {
        if (err) throw err;
        if (result.nModified == 0) {
            res.json({ "msg": "Record Update Failed" });
        } else {
            // console.log(result);
            // res.send("Record updated ...  ");
            res.json({ "msg": "Record updated succesfully" });
        }
    })

}

var DeleteProductInfo = (req, res) => {
    var deleteId = req.params.id;
    ProductModel.deleteOne({ _id: deleteId }, (err, result) => {
        if (err) throw err;
        // console.log(result);
        // res.send("Record Deleted " + result);
        if (result.deletedCount > 0) {
            res.json({ "msg": "Record deleted succesfully" });
        } else {
            res.json({ "msg": "Record not Present" });
        }
    })
}

module.exports = { GetProductFromDb, GetProductById, storeProductInfo, UpdateProductInfo, DeleteProductInfo }