var express = require("express");
const OrderController = require("../controllers/controller.order.js");
var router = express.Router();

router.post("/storeOrder", OrderController.storeOrderInfo); //store 

module.exports = router;