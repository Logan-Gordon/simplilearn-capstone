var express = require("express");
const BrandController = require("../controllers/controller.brand.js");
var router = express.Router();


router.get("/BrandFromDb", BrandController.GetBrandFromDb); // sub path
router.get("/BrandInfoById/:id", BrandController.GetBrandById); //sub path with path param
router.post("/storeBrand", BrandController.storeBrandInfo); //store Brand 
router.put("/updateBrand", BrandController.UpdateBrandInfo); //update Brand Details
router.delete("/deleteBrandByName/:bname", BrandController.DeleteBrandInfo); //delete Brand with path param

module.exports = router;