var express = require("express");
const productController = require("../controllers/controller.product");
var router = express.Router();

var ProductController = require("../controllers/controller.product");

router.get("/productFromDb", ProductController.GetProductFromDb); // sub path
router.get("/productInfoById/:id", ProductController.GetProductById); //sub path with path param
router.post("/storeProduct", ProductController.storeProductInfo); //store Product 
router.put("/updateProduct", ProductController.UpdateProductInfo); //update Product Details
router.delete("/deleteProductById/:id", ProductController.DeleteProductInfo); //delete Product with path param

module.exports = router;