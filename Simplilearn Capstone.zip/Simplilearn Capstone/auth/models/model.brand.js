var mongoose = require("mongoose");
mongoose.pluralize(null);

var BrandSchema = mongoose.Schema;

var BrandSchemaRef = new BrandSchema({
    bname: String
});

var BrandModel = mongoose.model("Brand", BrandSchemaRef);
module.exports = BrandModel;