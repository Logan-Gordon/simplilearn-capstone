var mongoose = require("mongoose");
mongoose.pluralize(null);

var ProductSchema = mongoose.Schema;

var ProductSchemaRef = new ProductSchema({
    _id: Number,
    name: String,
    details: String,
    image: String,
    price: Number,
    brand: String
});

var ProductModel = mongoose.model("Product", ProductSchemaRef);
module.exports = ProductModel;