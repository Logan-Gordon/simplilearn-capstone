var mongoose = require("mongoose");
mongoose.pluralize(null);

var OrderSchema = mongoose.Schema;

var OrderSchemaRef = new OrderSchema({
    order: {}
});

var OrderModel = mongoose.model("Order", OrderSchemaRef);
module.exports = OrderModel;