import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Brand } from '../models/model.brand';


@Injectable({
  providedIn: 'root'
})
export class BrandService {

  constructor(public httpClient:HttpClient) { }

  getAllBrandDetails():Observable<Brand[]>{
    return this.httpClient.get<Brand[]>("http://localhost:5000/brand/BrandFromDb");
  }

  storeBrandDetailsInDb(brandRef): Observable<any>{
    // this.httpClient.post("http://localhost:9090/products/storeProduct",prodRef).
    // subscribe(result=>console.log(result), error=>console.log(error));
  return this.httpClient.post("http://localhost:5000/brand/storeBrand",brandRef);
  }

  deleteBrandByName(bname):Observable<any>{
    return this.httpClient.delete("http://localhost:5000/brand/deleteBrandByName/" + bname);
  }

}
