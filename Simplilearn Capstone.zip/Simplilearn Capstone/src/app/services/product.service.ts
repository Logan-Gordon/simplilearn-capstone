import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from "../models/model.product";

@Injectable({
  providedIn: 'root'
})

export class ProductService{

  private products: Product[];

  constructor(public httpClient:HttpClient) { 
    this.getAllProductDetails().subscribe(result => this.products = result);
  }

  getAllProductDetails():Observable<Product[]>{
    return this.httpClient.get<Product[]>("http://localhost:5000/products/productFromDb");
  }

  storeProductsDetailsInDb(prodRef): Observable<any>{
  return this.httpClient.post("http://localhost:5000/products/storeProduct",prodRef);
  }

  getOneProductById(prodId):Observable<any>{
  return this.httpClient.get("http://localhost:5000/products/productInfoById/" + prodId);
  }

  deleteProductById(prodId):Observable<any>{
    return this.httpClient.delete("http://localhost:5000/products/deleteProductById/" + prodId);
  }
  
  updateProductDetailsFromDb(prodRef):Observable<any>{
    return this.httpClient.put("http://localhost:5000/products/updateProduct",prodRef);
  }

  findAll(): Product[] {
    return this.products;
}

find(id: number): Product {
    return this.products[this.getSelectedIndex(id)];
}

private getSelectedIndex(id: number) {
    for (var i = 0; i < this.products.length; i++) {
        if (this.products[i]._id == id) {
            return i;
        }
    }
    return -1;
}
}