import { Component, OnInit } from '@angular/core';
import { Product } from '../models/model.product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit {
  
  products: Product[];
  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.getAllProductDetails().subscribe(result => this.products = result);
  }

}
