import { Component, OnInit } from '@angular/core';
import { Brand } from '../models/model.brand';
import { BrandService } from '../services/brand.service';

@Component({
  selector: 'app-brand-list',
  templateUrl: './brand-list.component.html',
  styleUrls: ['./brand-list.component.css']
})
export class BrandListComponent implements OnInit {

  brands: Brand[];
  constructor(public brandService: BrandService) { }

  ngOnInit(): void {
    this.brandService.getAllBrandDetails().subscribe(result => this.brands = result);
  }
  
}