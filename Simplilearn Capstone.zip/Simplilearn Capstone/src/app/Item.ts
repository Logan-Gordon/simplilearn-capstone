import { Product } from './models/model.product';

export class Item {

    constructor(public product:Product, public quantity:number){}

 }