import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-update',
  templateUrl: './product-update.component.html',
  styleUrls: ['./product-update.component.css']
})
export class ProductUpdateComponent implements OnInit {

  result:string;

  prodRef = new FormGroup({
    _id: new FormControl(),
    name: new FormControl(),
    price: new FormControl(),
    image: new FormControl(),
    details: new FormControl(),
    brand: new FormControl() 
});

  constructor(public productService:ProductService) { }

  ngOnInit(): void {
  }

  updateProductDetails(){
    this.productService.updateProductDetailsFromDb(this.prodRef.value).subscribe(data=>this.result=data.msg);
    window.location.reload();
  }
}
