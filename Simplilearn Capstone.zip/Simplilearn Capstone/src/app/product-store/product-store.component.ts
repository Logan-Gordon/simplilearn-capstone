import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-store',
  templateUrl: './product-store.component.html',
  styleUrls: ['./product-store.component.css']
})
export class ProductStoreComponent implements OnInit {

  result:string;
  constructor(public productService:ProductService) { }

  prodRef = new FormGroup({
    _id: new FormControl(),
    name: new FormControl(),
    price: new FormControl(),
    image: new FormControl(),
    details: new FormControl(),
    brand: new FormControl() 
});

  ngOnInit(): void {
  }

  storeProductsDetails(): void{
    // console.log(this.productRef.value);
    this.productService.storeProductsDetailsInDb(this.prodRef.value)
    .subscribe(data=>this.result=data.msg);
    window.location.reload();
}
}
