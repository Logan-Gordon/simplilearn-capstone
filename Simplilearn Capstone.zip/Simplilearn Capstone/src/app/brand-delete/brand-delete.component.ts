import { Component, OnInit } from '@angular/core';
import { Brand } from '../models/model.brand';
import { BrandService } from '../services/brand.service';

@Component({
  selector: 'app-brand-delete',
  templateUrl: './brand-delete.component.html',
  styleUrls: ['./brand-delete.component.css']
})
export class BrandDeleteComponent implements OnInit {
  brands: Brand[];
  result:string;
  constructor(public brandService: BrandService) { }

  ngOnInit(): void {
    this.brandService.getAllBrandDetails().subscribe(result => this.brands = result);
  }

  deleteBrand(brandId){
    this.brandService.deleteBrandByName(brandId).subscribe(data=>this.result=data.msg);
    window.location.reload();
  }

}
