import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-retrieve-by-id',
  templateUrl: './product-retrieve-by-id.component.html',
  styleUrls: ['./product-retrieve-by-id.component.css']
})
export class ProductRetrieveByIdComponent implements OnInit {

  constructor(public productService: ProductService) { }

  ngOnInit(): void {
    // this.productService.getOneProductById().subscribe(result => this.products = result);
  }

}
