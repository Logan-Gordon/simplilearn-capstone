export class Order{
    constructor(public order:[]){}
}