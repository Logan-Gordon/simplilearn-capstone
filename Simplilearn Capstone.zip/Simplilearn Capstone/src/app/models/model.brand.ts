export class Brand{
    constructor(public bname:string){}
}