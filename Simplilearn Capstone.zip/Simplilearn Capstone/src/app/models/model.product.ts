export class Product{
    constructor(
        public _id:number, 
        public name: string,
        public details: string,
        public image: string,
        public price: number,
        public brand: string
        ){}
}