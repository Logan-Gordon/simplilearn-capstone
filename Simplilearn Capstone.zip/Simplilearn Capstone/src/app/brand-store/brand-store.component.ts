import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { BrandService } from '../services/brand.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-brand-store',
  templateUrl: './brand-store.component.html',
  styleUrls: ['./brand-store.component.css']
})
export class BrandStoreComponent implements OnInit {

  brandRef = new FormGroup({
    bname: new FormControl()
});

constructor(public brandService:BrandService, private router: Router) { }
result:string;
ngOnInit(): void {
}

storeBrandDetails(): void{
    // console.log(this.productRef.value);
    this.brandService.storeBrandDetailsInDb(this.brandRef.value)
    .subscribe(data=>this.result=data.msg);
    window.location.reload();
}

}