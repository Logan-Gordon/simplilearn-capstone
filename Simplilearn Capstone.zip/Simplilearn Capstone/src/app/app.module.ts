import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from "@angular/common/http";
import { AuthModule } from './auth/auth.module';
import { ServicesComponent } from './services/services.component';
import { BrandStoreComponent } from './brand-store/brand-store.component';
import { BrandListComponent } from './brand-list/brand-list.component';
import { BrandDeleteComponent } from './brand-delete/brand-delete.component';
import { ProductUpdateComponent } from './product-update/product-update.component';
import { ProductStoreComponent } from './product-store/product-store.component';
import { ProductRetrieveByIdComponent } from './product-retrieve-by-id/product-retrieve-by-id.component';
import { ProductDeleteComponent } from './product-delete/product-delete.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ShoppingComponent } from './shopping/shopping.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ProfileComponent,
    ServicesComponent,
    BrandStoreComponent,
    BrandListComponent,
    BrandDeleteComponent,
    ProductUpdateComponent,
    ProductStoreComponent,
    ProductRetrieveByIdComponent,
    ProductDeleteComponent,
    ProductListComponent,
    ShoppingComponent,
    CartComponent,
    CheckoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    AuthModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
